# Email Intelligence System

## Overview

This is a complete email intelligence system that extracts organization information from Gmail emails using AI and stores it in MongoDB. The system includes a Chrome extension for Gmail integration, a backend API with OpenAI integration, and a frontend dashboard for data management. Users can extract organization data directly from Gmail with one click or manually paste email content for processing.

## System Architecture

The application follows a modern full-stack architecture with Chrome extension integration:

### Chrome Extension Layer
- **Integration**: Direct Gmail integration with content scripts
- **Manifest**: Chrome Extension Manifest V3
- **Features**: In-page extraction button and popup interface
- **Data Transfer**: URL parameters and localStorage for seamless data flow
- **Security**: Gmail-only permissions with localhost backend access

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Radix UI components with shadcn/ui styling system
- **Styling**: Tailwind CSS with CSS variables for theming
- **Forms**: React Hook Form with Zod validation
- **Build Tool**: Vite for development and bundling
- **Extension Integration**: URL parameter handling and automatic data population

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ESM modules
- **API Pattern**: RESTful API endpoints
- **Validation**: Zod schemas for request/response validation
- **Database**: MongoDB primary storage with PostgreSQL schema compatibility
- **AI Integration**: OpenAI GPT-4o for intelligent content extraction
- **CORS**: Configured for Chrome extension and frontend access

### Data Storage Architecture
- **Primary Database**: MongoDB for organization data storage
- **Connection**: Remote MongoDB cluster (mongodb+srv://prachisri068:LvMPaEgy6bzzAMVf@cluster0.6gjts.mongodb.net/)
- **Secondary Database**: PostgreSQL with Drizzle ORM (schema defined for compatibility)
- **Schema Management**: Drizzle Kit for migrations and type safety

## Key Components

### 1. Chrome Extension for Gmail
- **Popup Interface**: Extension toolbar popup with extraction controls
- **Content Script**: Injected Gmail integration with extraction button
- **Email Detection**: Multiple selectors to reliably extract email content
- **Data Transfer**: Seamless data passing to dashboard via URL parameters
- **User Experience**: One-click extraction with visual feedback

### 2. AI-Powered Email Analysis
- **Implementation**: OpenAI GPT-4o integration with structured prompts
- **Intelligence**: Context-aware extraction from various email formats
- **Output**: Structured JSON with organization details (name, location, owners, activities, age, website, industry)
- **Error Handling**: Robust fallbacks and user feedback for extraction failures

### 3. Organization Data Management
- **CRUD Operations**: Complete create, read, update, delete functionality
- **Search & Filter**: Advanced text search and industry-based filtering
- **Data Validation**: Zod schemas ensure data integrity across the stack
- **Storage**: MongoDB with optimized indexing for performance

### 4. Dashboard Interface
- **Extraction Tab**: Manual email content processing with rich form interface
- **Database Tab**: Comprehensive organization listing with edit/view capabilities
- **Extension Integration**: Automatic data population from Chrome extension
- **Real-time Updates**: Optimistic updates with TanStack Query

## Data Flow

1. **Email Processing Flow**:
   - User pastes email content into the extraction form
   - Frontend validates input and sends to `/api/extract` endpoint
   - Backend calls OpenAI API with structured prompt
   - AI extracts organization data and returns structured JSON
   - Frontend displays extracted data in an editable form
   - User can review/edit and save to database

2. **Organization Management Flow**:
   - Organizations stored in MongoDB collections
   - REST API provides CRUD operations
   - Frontend uses React Query for caching and synchronization
   - Search and filtering performed server-side
   - Real-time updates via optimistic updates

3. **Database Operations**:
   - MongoDB handles organization data persistence
   - Connection pooling and error handling implemented
   - Indexed fields for efficient querying
   - Automatic timestamps for created/updated tracking

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database client
- **drizzle-orm**: Type-safe ORM for database operations
- **mongodb**: MongoDB driver for NoSQL operations
- **openai**: Official OpenAI API client
- **express**: Web framework for API endpoints

### UI Dependencies
- **@radix-ui/***: Accessible UI primitives
- **@tanstack/react-query**: Server state management
- **react-hook-form**: Form handling and validation
- **tailwindcss**: Utility-first CSS framework
- **zod**: Runtime type validation

### Development Dependencies
- **vite**: Build tool and dev server
- **typescript**: Static type checking
- **tsx**: TypeScript execution for development

## Deployment Strategy

### Development Environment
- **Dev Server**: Vite dev server with HMR for frontend
- **Backend**: tsx for running TypeScript directly
- **Database**: Environment variable configuration for database URLs
- **Environment**: NODE_ENV=development

### Production Build
- **Frontend**: Vite builds optimized static assets to `dist/public`
- **Backend**: esbuild bundles server code to `dist/index.js`
- **Database**: Drizzle migrations applied via `db:push` command
- **Startup**: `node dist/index.js` for production server

### Configuration Management
- Environment variables for sensitive data (API keys, database URLs)
- Separate development and production configurations
- Database connection strings managed via environment variables

## Chrome Extension Installation

### Quick Setup
1. Open Chrome and navigate to `chrome://extensions/`
2. Enable "Developer mode" toggle (top right)
3. Click "Load unpacked" and select the `chrome-extension` folder
4. Pin the extension to your toolbar for easy access

### Usage Methods
- **Extension Popup**: Click extension icon → "Extract from Current Email"
- **Gmail Integration**: Look for "Extract Organization Info" button in email view
- **Manual Entry**: Use dashboard "Extract from Email" tab for copy-paste

## Changelog

```
Changelog:
- June 29, 2025: Complete Email Intelligence System implemented
  - Chrome extension with Gmail integration
  - AI-powered organization extraction using OpenAI GPT-4o
  - MongoDB database with full CRUD operations
  - React dashboard with real-time data management
  - Seamless data flow from Gmail to dashboard
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```