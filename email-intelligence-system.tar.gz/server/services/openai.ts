import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key" 
});

export interface ExtractedOrganizationData {
  name: string;
  location: string;
  owners: string;
  activities: string;
  age: number;
  website: string;
  industry: string;
}

export async function extractOrganizationFromEmail(emailContent: string): Promise<ExtractedOrganizationData> {
  try {
    const prompt = `
    You are an AI assistant that extracts organization information from email content. 
    Please analyze the following email and extract the organization details in JSON format.
    
    Extract the following information:
    - name: Organization/company name
    - location: Organization location (city, state, country)
    - owners: Key personnel, owners, or leadership (comma separated)
    - activities: Business activities and services (brief description)
    - age: Company age in years (number only, if mentioned or can be calculated)
    - website: Company website URL
    - industry: Industry category
    
    If any information is not available, use empty string for text fields and 0 for age.
    
    Email content:
    ${emailContent}
    
    Respond with only valid JSON in the specified format.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert at extracting structured organization data from email content. Always respond with valid JSON."
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: { type: "json_object" },
      temperature: 0.1,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    // Validate and clean the extracted data
    return {
      name: result.name || "",
      location: result.location || "",
      owners: result.owners || "",
      activities: result.activities || "",
      age: parseInt(result.age) || 0,
      website: result.website || "",
      industry: result.industry || "",
    };
  } catch (error) {
    console.error("OpenAI extraction error:", error);
    throw new Error("Failed to extract organization information from email content");
  }
}
